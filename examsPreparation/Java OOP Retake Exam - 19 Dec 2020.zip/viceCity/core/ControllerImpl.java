package viceCity.core;

import viceCity.Main;
import viceCity.core.interfaces.Controller;
import viceCity.models.guns.BaseGun;
import viceCity.models.guns.Gun;
import viceCity.models.guns.Pistol;
import viceCity.models.guns.Rifle;
import viceCity.models.neighbourhood.GangNeighbourhood;
import viceCity.models.neighbourhood.Neighbourhood;
import viceCity.models.players.CivilPlayer;
import viceCity.models.players.MainPlayer;
import viceCity.models.players.Player;

import java.util.*;

import static viceCity.common.ConstantMessages.*;

public class ControllerImpl implements Controller {

    private MainPlayer mainPlayer;
    private Collection<Player> civilPlayers;
    private Deque<Gun> gunDeque;
    private Neighbourhood gangNeighbourhood;

    public ControllerImpl() {
        this.mainPlayer = new MainPlayer();
        this.civilPlayers = new LinkedList<>();
        this.gunDeque = new ArrayDeque<>();
        this.gangNeighbourhood = new GangNeighbourhood();
    }

    @Override
    public String addPlayer(String name) {
        civilPlayers.add(new CivilPlayer(name));
        return String.format(PLAYER_ADDED, name);
    }

    @Override
    public String addGun(String type, String name) {
        BaseGun baseGun;
        switch (type) {
            case "Pistol":
                baseGun = new Pistol(name);
                break;
            case "Rifle":
                baseGun = new Rifle(name);
                break;
            default:
                return GUN_TYPE_INVALID;
        }
        gunDeque.offer(baseGun);
        return String.format(GUN_ADDED, name, type);
    }

    @Override
    public String addGunToPlayer(String name) {
        if (this.gunDeque.isEmpty()) {
            return GUN_QUEUE_IS_EMPTY;
        }
        if (name.equals("Vercetti")) {
            mainPlayer.getGunRepository().add(gunDeque.peek());
            return String.format(GUN_ADDED_TO_MAIN_PLAYER, gunDeque.poll().getName(), mainPlayer.getName());
        }


        for (Player civilPlayer : civilPlayers) {
            if (civilPlayer.getName().equals(name)) {
                civilPlayer.getGunRepository().add(gunDeque.peek());
                return String.format(GUN_ADDED_TO_CIVIL_PLAYER, gunDeque.poll().getName(), name);
            }
        }
        return CIVIL_PLAYER_DOES_NOT_EXIST;
    }

    @Override
    public String fight() {
        gangNeighbourhood.action(mainPlayer, civilPlayers);
        if (mainPlayer.getLifePoints() == 100 && civilPlayers.stream().allMatch(Player::isAlive)) {
            return FIGHT_HOT_HAPPENED;
        }
        StringBuilder stringBuilder = new StringBuilder();
        int lifePoints = mainPlayer.getLifePoints();
        stringBuilder.append("A fight happened:").append(System.lineSeparator());
        stringBuilder.append(String.format(MAIN_PLAYER_LIVE_POINTS_MESSAGE,lifePoints)).append(System.lineSeparator());

        long count = civilPlayers.stream().filter(p -> !p.isAlive()).count();
        stringBuilder.append(String.format(MAIN_PLAYER_KILLED_CIVIL_PLAYERS_MESSAGE, count)).append(System.lineSeparator());

        long count1 = civilPlayers.stream().filter(Player::isAlive).count();
        stringBuilder.append(String.format(CIVIL_PLAYERS_LEFT_MESSAGE, count1));

        return stringBuilder.toString();

    }
}
