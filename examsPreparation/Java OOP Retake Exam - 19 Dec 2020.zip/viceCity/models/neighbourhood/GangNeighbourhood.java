package viceCity.models.neighbourhood;

import viceCity.models.guns.Gun;
import viceCity.models.players.Player;

import java.util.Collection;

public class GangNeighbourhood implements Neighbourhood {

    @Override
    public void action(Player mainPlayer, Collection<Player> civilPlayers) {

        Collection<Gun> models = mainPlayer.getGunRepository().getModels();

        for (Gun model : models) {

            for (Player civilPlayer : civilPlayers) {

                while (model.canFire() && civilPlayer.isAlive()) {
                    civilPlayer.takeLifePoints(model.fire());
                    model.canFire();
                }
                if (!model.canFire()) {
                    break;
                }

            }
        }

        for (Player civilPlayer : civilPlayers) {
            Collection<Gun> models1 = civilPlayer.getGunRepository().getModels();

            for (Gun gun : models1) {
                while (gun.canFire() && mainPlayer.isAlive()){
                    mainPlayer.takeLifePoints(gun.fire());
                }
                if (!gun.canFire()){
                    models1.remove(gun);
                }
                if (!mainPlayer.isAlive()){
                    break;
                }
            }
            if (!mainPlayer.isAlive()){
                break;
            }
        }

    }
}

