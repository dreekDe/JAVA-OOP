package viceCity.models.guns;

public class Pistol extends BaseGun{

    private static final int BULLETS = 10;
    private static final int TOTAL_BULLETS = 100;

    public Pistol(String name) {
        super(name, BULLETS, TOTAL_BULLETS);
    }

    @Override
    public boolean canFire() {
            if (super.getBulletsPerBarrel() > 0 ){
                return true;
            }else if (this.getBulletsPerBarrel() == 0 && this.getTotalBullets()>= BULLETS){
                this.setBulletsPerBarrel(BULLETS);
                this.setTotalBullets(this.getTotalBullets()- BULLETS);
            }return false ;
    }

    @Override
    public int fire() {
    super.setBulletsPerBarrel(super.getBulletsPerBarrel()-1);
        return 1;
    }
}
