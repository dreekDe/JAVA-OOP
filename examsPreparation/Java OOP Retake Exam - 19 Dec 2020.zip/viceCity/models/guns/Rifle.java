package viceCity.models.guns;

public class Rifle extends BaseGun {
    private static final int BULLETS = 50;
    private static final int TOTAL_BULLETS = 500;

    public Rifle(String name) {
        super(name, BULLETS, TOTAL_BULLETS);
    }


    @Override
    public boolean canFire() {
        if (super.getTotalBullets() > 0 ){
            return true;
        }else if (this.getBulletsPerBarrel() == 0 && this.getTotalBullets()>= BULLETS){
            this.setBulletsPerBarrel(BULLETS);
            this.setTotalBullets(this.getTotalBullets()- BULLETS);
        }return false ;
    }

    @Override
    public int fire() {
        if (super.getBulletsPerBarrel() == 0 && super.getTotalBullets() >= BULLETS) {
            super.setBulletsPerBarrel(BULLETS);
            super.setTotalBullets(super.getTotalBullets() - BULLETS);
        }
        super.setTotalBullets(super.getTotalBullets() - 5);
        return 5;
    }
}
