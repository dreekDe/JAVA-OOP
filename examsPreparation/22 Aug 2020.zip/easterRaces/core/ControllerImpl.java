package easterRaces.core;

import easterRaces.core.interfaces.Controller;
import easterRaces.entities.cars.Car;
import easterRaces.entities.cars.MuscleCar;
import easterRaces.entities.cars.SportsCar;
import easterRaces.entities.drivers.Driver;
import easterRaces.entities.drivers.DriverImpl;
import easterRaces.entities.racers.Race;
import easterRaces.entities.racers.RaceImpl;
import easterRaces.repositories.interfaces.Repository;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static easterRaces.common.ExceptionMessages.*;
import static easterRaces.common.OutputMessages.*;

public class ControllerImpl implements Controller {
    private Repository<Driver> driverRepository;
    private Repository<Car> carRepository;
    private Repository<Race> raceRepository;

    public ControllerImpl(Repository<Driver> driverRepository, Repository<Car> carRepository, Repository<Race> raceRepository) {
        this.driverRepository = driverRepository;
        this.carRepository = carRepository;
        this.raceRepository = raceRepository;
    }

    @Override
    public String createDriver(String driver) {

        if (this.driverRepository.getByName(driver) != null) {
            throw new IllegalArgumentException(String.format(DRIVER_EXISTS, driver));
        }

        Driver createNewDriver = new DriverImpl(driver);
        this.driverRepository.add(createNewDriver);
        return String.format(DRIVER_CREATED, driver);
    }

    @Override
    public String createCar(String type, String model, int horsePower) {

        if(this.carRepository.getByName(model) != null) {
            throw new IllegalArgumentException(String.format(CAR_EXISTS, model));
        }

        Car car = null;
        if (type.equals("Muscle")) {
            car = new MuscleCar(model, horsePower);
        } else if (type.equals("Sports")){
            car = new SportsCar(model, horsePower);
        }

        this.carRepository.add(car);

        return String.format(CAR_CREATED,car.getClass().getSimpleName(), model);
    }

    @Override
    public String addCarToDriver(String driverName, String carModel) {

        if (this.driverRepository.getByName(driverName) == null) {
            throw new IllegalArgumentException(String.format(DRIVER_NOT_FOUND, driverName));
        }else if(this.carRepository.getByName(carModel) == null) {
            throw new IllegalArgumentException(String.format(CAR_NOT_FOUND, carModel));
        }

        Car car = this.carRepository.getByName(carModel);
        this.driverRepository.getByName(driverName).addCar(car);

        return String.format(CAR_ADDED, driverName, carModel);
    }

    @Override
    public String addDriverToRace(String raceName, String driverName) {

        if (this.raceRepository.getByName(raceName) == null) {
            throw new IllegalArgumentException(String.format(RACE_NOT_FOUND, raceName));
        }else if (this.driverRepository.getByName(driverName) == null) {
            throw new IllegalArgumentException(String.format(DRIVER_NOT_FOUND, driverName));
        }

        Driver driver = this.driverRepository.getByName(driverName);
        this.raceRepository.getByName(raceName).addDriver(driver);
        return String.format(DRIVER_ADDED, driverName, raceName);
    }

    @Override
    public String createRace(String name, int laps) {

        if (this.raceRepository.getByName(name) != null) {
            throw new IllegalArgumentException(String.format(RACE_EXISTS, name));
        }

        Race race = new RaceImpl(name, laps);
        this.raceRepository.add(race);

        return String.format(RACE_CREATED, name);
    }

    @Override
    public String startRace(String raceName) {

        if (this.raceRepository.getByName(raceName) == null) {
            throw new IllegalArgumentException(String.format(RACE_NOT_FOUND, raceName));
        }

        if(this.driverRepository.getAll().size() < 3) {
            throw new IllegalArgumentException(String.format(RACE_INVALID, raceName, 3));
        }

        int laps = this.raceRepository.getByName(raceName).getLaps();
        Collection<Driver> drivers = this.raceRepository.getByName(raceName).getDrivers();
        List<Driver> driverList = drivers.stream()
                .sorted((f, s) -> Double.compare(s.getCar().calculateRacePoints(laps), f.getCar().calculateRacePoints(laps)))
                .collect(Collectors.toList());

        StringBuilder output = new StringBuilder();

        output.append(String.format(DRIVER_FIRST_POSITION, driverList.get(0).getName(), raceName)).append(System.lineSeparator());
        output.append(String.format(DRIVER_SECOND_POSITION, driverList.get(1).getName(), raceName)).append(System.lineSeparator());
        output.append(String.format(DRIVER_THIRD_POSITION, driverList.get(2).getName(), raceName));

        this.raceRepository.remove(this.raceRepository.getByName(raceName));

        return output.toString().trim();
    }


}
