package easterRaces.common;

public enum Command {
    CreateDriver,
    CreateCar,
    AddCarToDriver,
    AddDriverToRace,
    CreateRace,
    StartRace,
    End
}
