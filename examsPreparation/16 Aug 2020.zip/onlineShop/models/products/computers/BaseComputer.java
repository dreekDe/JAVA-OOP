package onlineShop.models.products.computers;

import onlineShop.models.products.BaseProduct;
import onlineShop.models.products.Product;
import onlineShop.models.products.components.Component;
import onlineShop.models.products.peripherals.Peripheral;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static onlineShop.common.constants.ExceptionMessages.*;
import static onlineShop.common.constants.OutputMessages.*;

public abstract class BaseComputer extends BaseProduct implements Computer {
    private List<Component> components;
    private List<Peripheral> peripherals;

    protected BaseComputer(int id, String manufacturer, String model, double price, double overallPerformance) {
        super(id, manufacturer, model, price, overallPerformance);
        this.components = new ArrayList<>();
        this.peripherals = new ArrayList<>();

    }

    @Override
    public double getOverallPerformance() {
        if (components == null) {
            return super.getOverallPerformance();
        }
        return super.getOverallPerformance() + components.stream().mapToDouble(Component::getOverallPerformance).average().orElse(0.0);
    }

    @Override
    public double getPrice() {
        return super.getPrice() +
                components.stream().mapToDouble(Product::getPrice).sum() +
                peripherals.stream().mapToDouble(Product::getPrice).sum();

    }

    @Override
    public List<Component> getComponents() {
        return Collections.unmodifiableList(components);
    }

    @Override
    public List<Peripheral> getPeripherals() {
        return Collections.unmodifiableList(peripherals);
    }

    @Override
    public void addComponent(Component component) {
        for (Component component1 : components) {
            if (component1.equals(component)) {
                throw new IllegalArgumentException(String.format(EXISTING_COMPONENT, component, this.getClass().getSimpleName(), this.getId()));
            }
        }
        this.components.add(component);

    }

    @Override
    public Component removeComponent(String componentType) {
        for (Component component : components) {
            if (component.getClass().getSimpleName().equals(componentType)) {
                components.remove(component);
                return component;
            }
        }
        throw new IllegalArgumentException(String.format(NOT_EXISTING_COMPONENT, componentType, this.getClass().getSimpleName(), this.getId()));
    }

    @Override
    public void addPeripheral(Peripheral peripheral) {
        for (Peripheral peripheral1 : peripherals) {
            if (peripheral.equals(peripheral1)) {
                throw new IllegalArgumentException(String.format(EXISTING_PERIPHERAL, peripheral, this.getClass().getSimpleName(), this.getId()));
            }
        }
        this.peripherals.add(peripheral);
    }

    @Override
    public Peripheral removePeripheral(String peripheralType) {
        for (Peripheral peripheral : peripherals) {
            if (peripheral.getClass().getSimpleName().equals(peripheralType)) {
                peripherals.remove(peripheral);
                return peripheral;
            }
        }
        throw new IllegalArgumentException(String.format(NOT_EXISTING_PERIPHERAL, peripheralType, this.getClass().getSimpleName(), this.getId()));
    }

    private double averageOverallPerformance (){
        return this.peripherals.stream().mapToDouble(Product::getOverallPerformance).average().orElse(0.0);
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(super.toString());
        stringBuilder.append(System.lineSeparator());
        stringBuilder.append(" ").append(String.format(COMPUTER_COMPONENTS_TO_STRING, this.components.size())).append(System.lineSeparator());
        for (Component component : components) {
            stringBuilder.append("  ").append(component.toString()).append(System.lineSeparator());
        }
        stringBuilder.append(" ").append(String.format(COMPUTER_PERIPHERALS_TO_STRING, this.peripherals.size(), averageOverallPerformance())).append(System.lineSeparator());
        for (Peripheral peripheral : peripherals) {
            stringBuilder.append("  ").append(peripheral.toString()).append(System.lineSeparator());
        }
        return stringBuilder.toString().trim();
    }
}
