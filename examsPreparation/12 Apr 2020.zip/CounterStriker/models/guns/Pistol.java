package CounterStriker.models.guns;

public class Pistol extends GunImpl {

    private static final int PISTOL_BULLET = 1;

    public Pistol(String username, int bulletsCount) {
        super(username, bulletsCount);
    }

    @Override
    public int fire() {
        int result = 0;
        if (super.getBulletsCount() - PISTOL_BULLET >= 0) {
            super.setBulletsCount(super.getBulletsCount() - PISTOL_BULLET);
            result = PISTOL_BULLET;
        }
        return result;
    }
}
