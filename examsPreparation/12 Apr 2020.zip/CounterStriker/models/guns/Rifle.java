package CounterStriker.models.guns;

import java.util.Random;

public class Rifle extends GunImpl {

    private static final int RIFLE_BULLET = 10;

    public Rifle(String username, int bulletsCount) {
        super(username, bulletsCount);
    }

    @Override
    public int fire() {
        int result = 0;
        if (super.getBulletsCount() - RIFLE_BULLET >= 0) {
            super.setBulletsCount(super.getBulletsCount() - RIFLE_BULLET);
            result = RIFLE_BULLET;
        }
        return result;
    }
}
