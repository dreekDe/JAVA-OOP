package CounterStriker.models.players;

import CounterStriker.models.guns.Gun;

import java.util.Objects;

import static CounterStriker.common.ExceptionMessages.*;

public abstract class PlayerImpl implements Player {

    private String username;
    private int health;
    private int armor;
    private boolean isAlive;
    private Gun gun;

    protected PlayerImpl(String username, int health, int armor, Gun gun) {
        this.setUsername(username);
        this.setHealth(health);
        this.setArmor(armor);
        this.setGun(gun);
        this.isAlive = true;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new NullPointerException(INVALID_PLAYER_NAME);
        }
        this.username = username;
    }

    @Override
    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        if (health < 0) {
            throw new IllegalArgumentException(INVALID_PLAYER_HEALTH);
        }
        this.health = health;
    }

    @Override
    public int getArmor() {
        return armor;
    }

    public void setArmor(int armor) {
        if (armor < 0) {
            throw new IllegalArgumentException(INVALID_PLAYER_ARMOR);
        }
        this.armor = armor;
    }

    @Override
    public boolean isAlive() {
        return this.getHealth() > 0;
    }

    public void setAlive(boolean alive) {
        isAlive = alive;
    }

    @Override
    public Gun getGun() {
        return gun;
    }

    public void setGun(Gun gun) {
        if (gun == null) {
            throw new NullPointerException(INVALID_GUN);
        }
        this.gun = gun;
    }

    public void takeDamage(int points) {

        if (this.getArmor() - points < 0) {
            this.setArmor(0);
            if (getHealth() - points <= 0) {
                this.setHealth(0);
                isAlive = false;
            }else{
                this.setHealth(this.getHealth() - points);
            }
        } else {
            this.setArmor(this.getArmor() - points);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PlayerImpl player = (PlayerImpl) o;
        return health == player.health &&
                armor == player.armor &&
                isAlive == player.isAlive &&
                Objects.equals(username, player.username) &&
                Objects.equals(gun, player.gun);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username, health, armor, isAlive, gun);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(String
                .format("%s: %s", this.getClass().getSimpleName(), this.getUsername()))
                .append(System.lineSeparator());
        sb.append(String.format("--Health: %d", this.getHealth())).append(System.lineSeparator());
        sb.append(String.format("--Armor: %d", this.getArmor())).append(System.lineSeparator());
        sb.append(String.format("--Gun: %s", this.getGun().getName())).append(System.lineSeparator());
        return sb.toString();
    }
}
